package lecho.lib.hellocharts.gesture;

/**
 * Enum used to inform chart in which type of container it exists.
 */
public enum ContainerScrollType {
    HORIZONTAL, VERTICAL
}
